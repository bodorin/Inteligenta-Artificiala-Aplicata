"""AG cu codificare reală în DEAP: minimizarea funcției Rastrigin (n = 10), comparație între operatori.
Necesită: pip install deap numpy       Rulare: python s05_deap_rastrigin.py"""
import random, math, statistics, time
import numpy as np
from deap import base, creator, tools, algorithms

N, LO, HI = 10, -5.12, 5.12
def rastrigin(x):                      # minim global 0 în x = 0; ~10^n minime locale
    return (10 * len(x) + sum(xi * xi - 10 * math.cos(2 * math.pi * xi) for xi in x),)

creator.create("FitnessMin", base.Fitness, weights=(-1.0,))      # -1 = minimizare
creator.create("Individual", list, fitness=creator.FitnessMin)

def make_toolbox(cx, sel_k=3, sigma=0.3, indpb=0.1):
    tb = base.Toolbox()
    tb.register("attr", random.uniform, LO, HI)
    tb.register("individual", tools.initRepeat, creator.Individual, tb.attr, N)
    tb.register("population", tools.initRepeat, list, tb.individual)
    tb.register("evaluate", rastrigin)
    if cx == "blend":
        tb.register("mate", tools.cxBlend, alpha=0.5)                             # BLX-0.5
    elif cx == "sbx":
        tb.register("mate", tools.cxSimulatedBinaryBounded, eta=15, low=LO, up=HI)
    else:
        tb.register("mate", tools.cxTwoPoint)
    tb.register("mutate", tools.mutGaussian, mu=0, sigma=sigma, indpb=indpb)
    tb.register("select", tools.selTournament, tournsize=sel_k)
    def clip(func):                                    # decorator: readuce genele în domeniu
        def wrapper(*args, **kw):
            off = func(*args, **kw)
            for ind in off:
                for i in range(len(ind)): ind[i] = min(HI, max(LO, ind[i]))
            return off
        return wrapper
    tb.decorate("mate", clip); tb.decorate("mutate", clip)
    return tb

def run(cx, seed, ngen=200, mu=100, mode="simple", **kw):
    random.seed(seed); np.random.seed(seed)
    tb = make_toolbox(cx, **kw)
    pop, hof = tb.population(n=mu), tools.HallOfFame(1)
    if mode == "simple":       # AG generațional cu elitism implicit doar prin Hall of Fame
        algorithms.eaSimple(pop, tb, cxpb=0.8, mutpb=0.2, ngen=ngen, halloffame=hof, verbose=False)
    else:                      # (μ + λ): părinți și copii concurează pentru supraviețuire
        algorithms.eaMuPlusLambda(pop, tb, mu=mu, lambda_=mu, cxpb=0.7, mutpb=0.3, ngen=ngen, halloffame=hof, verbose=False)
    return hof[0].fitness.values[0]

if __name__ == "__main__":
    configs = [("2 puncte, generațional", dict(cx="twopoint")),
               ("BLX-0.5, generațional", dict(cx="blend")),
               ("SBX, generațional", dict(cx="sbx")),
               ("SBX, (μ+λ)", dict(cx="sbx", mode="mupluslambda")),
               ("SBX, (μ+λ), turnir k=7", dict(cx="sbx", mode="mupluslambda", sel_k=7))]
    print(f"Rastrigin n={N}, 100 indivizi × 200 generații, 10 rulări (mai mic = mai bine)")
    for name, cfg in configs:
        t = time.perf_counter()
        res = [run(seed=s, **cfg) for s in range(10)]
        print(f"  {name:26s} medie={statistics.mean(res):7.3f}  std={statistics.stdev(res):6.3f}  "
              f"min={min(res):6.3f}  timp/rulare={(time.perf_counter()-t)/10:.2f}s")
