"""Algoritmul genetic canonic (Holland/Goldberg), scris de la zero.
Codificare binară, selecție proporțională (ruletă), încrucișare cu un punct, mutație prin inversarea biților.
Rulare: python s04_ga_basic.py"""
import random

def decode(bits):                         # cromozom binar -> întreg
    return int("".join(map(str, bits)), 2)

def roulette(pop, fits, rng):
    """Selecție proporțională: P(i) = f_i / Σ f_j (necesită fitness ≥ 0)."""
    total = sum(fits)
    if total == 0:
        return rng.choice(pop)
    r, acc = rng.uniform(0, total), 0.0
    for ind, f in zip(pop, fits):
        acc += f
        if acc >= r:
            return ind
    return pop[-1]

def one_point(p1, p2, rng):
    c = rng.randint(1, len(p1) - 1)       # punct de tăietură
    return p1[:c] + p2[c:], p2[:c] + p1[c:]

def mutate(ind, pm, rng):
    return [1 - b if rng.random() < pm else b for b in ind]

def ga(fitness, n_bits, pop_size=20, pc=0.8, pm=0.01, generations=50, seed=1, elitism=False, verbose=False):
    rng = random.Random(seed)
    pop = [[rng.randint(0, 1) for _ in range(n_bits)] for _ in range(pop_size)]
    history = []
    for gen in range(generations):
        fits = [fitness(ind) for ind in pop]
        best = max(range(pop_size), key=fits.__getitem__)
        history.append((max(fits), sum(fits) / pop_size))
        if verbose:
            print(f"gen {gen:3d}  best={max(fits):8.1f}  medie={sum(fits)/pop_size:8.1f}  {''.join(map(str, pop[best]))}")
        new = [pop[best][:]] if elitism else []
        while len(new) < pop_size:
            p1, p2 = roulette(pop, fits, rng), roulette(pop, fits, rng)
            c1, c2 = one_point(p1, p2, rng) if rng.random() < pc else (p1[:], p2[:])
            new += [mutate(c1, pm, rng), mutate(c2, pm, rng)]
        pop = new[:pop_size]
    fits = [fitness(ind) for ind in pop]
    best = max(range(pop_size), key=fits.__getitem__)
    return pop[best], fits[best], history

def hill_climbing(fitness, n_bits, evals, seed=1):
    """Termen de comparație: urcare cu prima îmbunătățire, cu restart aleator."""
    rng, used, best_f, best = random.Random(seed), 0, -1, None
    while used < evals:
        x = [rng.randint(0, 1) for _ in range(n_bits)]; fx = fitness(x); used += 1
        improved = True
        while improved and used < evals:
            improved = False
            for i in rng.sample(range(n_bits), n_bits):
                y = x[:]; y[i] ^= 1; fy = fitness(y); used += 1
                if fy > fx:
                    x, fx, improved = y, fy, True; break
                if used >= evals: break
        if fx > best_f:
            best_f, best = fx, x
    return best, best_f

if __name__ == "__main__":
    print("== Problema 1 (Goldberg): maximizăm f(x) = x², x ∈ {0..31}, 5 biți")
    best, f, _ = ga(lambda b: decode(b) ** 2, 5, pop_size=4, generations=6, pm=0.001, seed=3, verbose=True)
    print("rezultat:", best, "x =", decode(best), "f =", f)

    print("\n== Problema 2: OneMax cu 60 de biți (maximul = 60)")
    for elit in (False, True):
        res = [ga(sum, 60, pop_size=50, pm=1/60, generations=100, seed=s, elitism=elit)[1] for s in range(10)]
        print(f"GA {'cu' if elit else 'fără'} elitism: medie {sum(res)/10:.1f}, cel mai bun {max(res)}")
    res = [hill_climbing(sum, 60, evals=50 * 100, seed=s)[1] for s in range(10)]
    print(f"Hill climbing (același buget de evaluări): medie {sum(res)/10:.1f}")

    print("\n== Problema 3: funcție-capcană (deceptivă), 10 blocuri a câte 4 biți (maximul = 40)")
    def trap(b, k=4):                       # blocul valorează k dacă e plin de 1, altfel k−1−(numărul de 1)
        s = 0
        for i in range(0, len(b), k):
            u = sum(b[i:i + k]); s += k if u == k else k - 1 - u
        return s
    res = [ga(trap, 40, pop_size=100, pm=1/40, generations=100, seed=s, elitism=True)[1] for s in range(10)]
    print(f"GA: medie {sum(res)/10:.1f}, cel mai bun {max(res)}")
    res = [hill_climbing(trap, 40, evals=100 * 100, seed=s)[1] for s in range(10)]
    print(f"Hill climbing: medie {sum(res)/10:.1f}, cel mai bun {max(res)}")
