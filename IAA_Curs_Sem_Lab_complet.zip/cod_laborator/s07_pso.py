"""Optimizarea cu roiuri de particule (PSO): varianta globală cu inerție și varianta cu factor de constricție.
Funcția Rastrigin, n = 10 (aceeași ca în ședința 5).   Rulare: python s07_pso.py"""
import random, math, statistics

N_DIM, LO, HI = 10, -5.12, 5.12
def rastrigin(x):
    return 10 * len(x) + sum(xi * xi - 10 * math.cos(2 * math.pi * xi) for xi in x)
def sphere(x):
    return sum(xi * xi for xi in x)

def pso(f, n=40, iters=500, w=0.729, c1=1.49445, c2=1.49445, w_end=None, topology="global", seed=0):
    """v ← w·v + c1·r1·(pbest − x) + c2·r2·(gbest − x);  x ← x + v.
    Parametrii impliciți = constricția lui Clerc & Kennedy (χ = 0,729, φ1 = φ2 = 2,05 → c = χ·φ ≈ 1,494)."""
    rng = random.Random(seed)
    vmax = 0.2 * (HI - LO)
    X = [[rng.uniform(LO, HI) for _ in range(N_DIM)] for _ in range(n)]
    V = [[rng.uniform(-vmax, vmax) for _ in range(N_DIM)] for _ in range(n)]
    P = [x[:] for x in X]; Pf = [f(x) for x in X]                       # cele mai bune poziții personale
    history = []
    for t in range(iters):
        wt = w if w_end is None else w + (w_end - w) * t / iters           # inerție descrescătoare (opțional)
        for i in range(n):
            if topology == "global":
                g = min(range(n), key=Pf.__getitem__)
            else:                                                           # topologie inel: vecinii i−1, i, i+1
                g = min(((i - 1) % n, i, (i + 1) % n), key=Pf.__getitem__)
            for d in range(N_DIM):
                r1, r2 = rng.random(), rng.random()
                V[i][d] = wt * V[i][d] + c1 * r1 * (P[i][d] - X[i][d]) + c2 * r2 * (P[g][d] - X[i][d])
                V[i][d] = max(-vmax, min(vmax, V[i][d]))                    # limitarea vitezei
                X[i][d] = max(LO, min(HI, X[i][d] + V[i][d]))
            fx = f(X[i])
            if fx < Pf[i]: P[i], Pf[i] = X[i][:], fx
        history.append(min(Pf))
    return min(Pf), history

if __name__ == "__main__":
    print("Sphere n=10 (unimodală):  PSO global =", f"{pso(sphere, seed=0)[0]:.2e}")
    print("Rastrigin n=10, 40 particule × 500 iterații = 20 000 de evaluări, 10 rulări:")
    cfgs = [("global, constricție", {}),
            ("inel, constricție", {"topology": "ring"}),
            ("global, w 0.9→0.4, c=2", {"w": 0.9, "w_end": 0.4, "c1": 2.0, "c2": 2.0}),
            ("global, w=1 (fără amortizare)", {"w": 1.0, "c1": 2.0, "c2": 2.0})]
    for name, kw in cfgs:
        res = [pso(rastrigin, seed=s, **kw)[0] for s in range(10)]
        print(f"  {name:30s} medie={statistics.mean(res):7.3f}  std={statistics.stdev(res):6.3f}  min={min(res):6.3f}")
