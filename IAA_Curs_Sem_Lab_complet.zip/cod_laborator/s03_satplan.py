"""SATPlan: planificare ca satisfiabilitate în logica propozițională (Kautz & Selman).
Pentru T = 0, 1, 2, ... codificăm „există un plan de T pași” ca formulă CNF și o dăm unui rezolvitor SAT.
Necesită: pip install python-sat      Rulare: python s03_satplan.py"""
from itertools import combinations
from pysat.solvers import Glucose3
from s02_strips import blocks_world, towers

class Encoder:
    def __init__(self):
        self.ids, self.names = {}, {}
    def var(self, name):                    # simbol propozițional -> întreg (format DIMACS)
        if name not in self.ids:
            self.ids[name] = len(self.ids) + 1
            self.names[self.ids[name]] = name
        return self.ids[name]

def conflict(a, b):
    """a și b nu pot fi executate în același pas (paralel): una șterge o precondiție sau un efect al celeilalte."""
    return bool(a.dele & (b.pre | b.add)) or bool(b.dele & (a.pre | a.add))

def encode(p, T):
    E, cnf = Encoder(), []
    fluents = sorted(set(p.init) | set(p.goal) | {f for a in p.actions for f in a.pre | a.add | a.dele})
    F = lambda f, t: E.var(f"{f}@{t}")
    def A(a, t):
        v = E.var(f"{a.name}@{t}"); E.action_vars[v] = (a.name, t); return v
    E.action_vars = {}
    for f in fluents:                       # 1. starea inițială (lumea închisă)
        cnf.append([F(f, 0)] if f in p.init else [-F(f, 0)])
    for g in p.goal:                        # 2. scopul la momentul T
        cnf.append([F(g, T)])
    for t in range(T):
        for a in p.actions:                 # 3. precondiții și efecte
            for q in a.pre:  cnf.append([-A(a, t), F(q, t)])
            for q in a.add:  cnf.append([-A(a, t), F(q, t + 1)])
            for q in a.dele - a.add: cnf.append([-A(a, t), -F(q, t + 1)])
        for f in fluents:                   # 4. axiome-cadru explicative: o schimbare cere o cauză
            adders = [A(a, t) for a in p.actions if f in a.add]
            deleters = [A(a, t) for a in p.actions if f in a.dele]
            cnf.append([F(f, t), -F(f, t + 1)] + adders)      # f fals -> adevărat  => o acțiune îl adaugă
            cnf.append([-F(f, t), F(f, t + 1)] + deleters)    # f adevărat -> fals => o acțiune îl șterge
        for a, b in combinations(p.actions, 2):  # 5. excluderea acțiunilor conflictuale
            if conflict(a, b):
                cnf.append([-A(a, t), -A(b, t)])
    return E, cnf

def satplan(p, T_max=20):
    for T in range(T_max + 1):
        E, cnf = encode(p, T)
        with Glucose3(bootstrap_with=cnf) as s:
            if s.solve():
                model = {v for v in s.get_model() if v > 0}
                steps = [[] for _ in range(T)]
                for v in model:
                    if v in E.action_vars:           # citim din model doar variabilele-acțiune adevărate
                        act, t = E.action_vars[v]; steps[t].append(act)
                return T, steps, len(E.ids), len(cnf)
        print(f"  T={T:2d}: nesatisfiabil  ({len(E.ids)} variabile, {len(cnf)} clauze)")
    return None

if __name__ == "__main__":
    sussman = blocks_world(towers([["A", "C"], ["B"]]), {"on(A,B)", "on(B,C)"}, "ABC")
    T, steps, nv, nc = satplan(sussman)
    print(f"Sussman: plan găsit la T={T} ({nv} variabile, {nc} clauze)")
    for t, st in enumerate(steps):
        print(f"  pas {t}: {st}")
