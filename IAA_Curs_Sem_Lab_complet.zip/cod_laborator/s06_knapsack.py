"""Problema rucsacului 0/1 cu AG: cinci metode de tratare a restricției de capacitate.
Comparație cu optimul exact (programare dinamică).   Rulare: python s06_knapsack.py"""
import random, statistics

def instance(n=50, seed=7):
    """Instanță „corelată” (mai grea): valoarea ≈ greutatea + 10 (Michalewicz, cap. 4)."""
    r = random.Random(seed)
    w = [r.randint(1, 50) for _ in range(n)]
    v = [wi + 10 for wi in w]
    return w, v, sum(w) // 2                # capacitate = jumătate din greutatea totală
W, V, CAP = instance()
N = len(W)

def dp_optimum(w, v, cap):
    best = [0] * (cap + 1)
    for wi, vi in zip(w, v):
        for c in range(cap, wi - 1, -1):
            best[c] = max(best[c], best[c - wi] + vi)
    return best[cap]

def weight(x): return sum(wi for wi, xi in zip(W, x) if xi)
def value(x):  return sum(vi for vi, xi in zip(V, x) if xi)

# ---------- metode de tratare a restricției (maximizare) ----------
RHO = max(v / w for v, w in zip(V, W))     # raportul maxim valoare/greutate

def fit_death(x):                           # „pedeapsa cu moartea”: soluțiile nefezabile primesc 0
    return value(x) if weight(x) <= CAP else 0

def fit_penalty_lin(x):                     # penalizare liniară (Michalewicz): ρ · exces
    return value(x) - RHO * max(0, weight(x) - CAP)

def fit_penalty_sq(x):                      # penalizare pătratică
    return value(x) - (RHO * max(0, weight(x) - CAP)) ** 2

ORDER = sorted(range(N), key=lambda i: V[i] / W[i])     # de la cel mai slab raport la cel mai bun
def repair(x):
    """Reparare lacomă: scoatem obiectele cu cel mai mic raport v/w până devine fezabil."""
    x, wt = x[:], weight(x)
    for i in ORDER:
        if wt <= CAP: break
        if x[i]: x[i] = 0; wt -= W[i]
    return x

def decode_perm(p):
    """Decodificator: permutarea dă ordinea în care încercăm să adăugăm obiectele (mereu fezabil)."""
    x, wt = [0] * N, 0
    for i in p:
        if wt + W[i] <= CAP: x[i] = 1; wt += W[i]
    return x

# ---------- AG generic (turnir, elitism) ----------
def ga(kind, pop_size=60, gens=150, seed=0, lamarck_p=0.05):
    rng = random.Random(seed)
    if kind == "decoder":
        new = lambda: rng.sample(range(N), N)
        def cross(a, b):                     # OX pe permutări
            i, j = sorted(rng.sample(range(N + 1), 2)); seg = a[i:j]
            rest = [g for g in b if g not in seg]; return rest[:i] + seg + rest[i:]
        def mut(a):
            a = a[:]; i, j = rng.sample(range(N), 2); a[i], a[j] = a[j], a[i]; return a
        evaluate = lambda p: value(decode_perm(p))
    else:
        new = lambda: [1 if rng.random() < 0.5 else 0 for _ in range(N)]
        def cross(a, b):
            c = rng.randint(1, N - 1); return a[:c] + b[c:]
        mut = lambda a: [1 - g if rng.random() < 1 / N else g for g in a]
        evaluate = {"death": fit_death, "pen_lin": fit_penalty_lin, "pen_sq": fit_penalty_sq,
                    "repair": lambda x: value(repair(x))}[kind]
    pop = [new() for _ in range(pop_size)]
    best_feasible = 0
    for _ in range(gens):
        fits = [evaluate(x) for x in pop]
        for x in pop:                        # urmărim cea mai bună soluție FEZABILĂ întâlnită
            sol = decode_perm(x) if kind == "decoder" else (repair(x) if kind == "repair" else x)
            if weight(sol) <= CAP: best_feasible = max(best_feasible, value(sol))
        elite = pop[max(range(pop_size), key=fits.__getitem__)]
        nxt = [elite]
        while len(nxt) < pop_size:
            p1 = max(rng.sample(range(pop_size), 2), key=fits.__getitem__)
            p2 = max(rng.sample(range(pop_size), 2), key=fits.__getitem__)
            c = mut(cross(pop[p1], pop[p2]) if rng.random() < 0.9 else pop[p1][:])
            if kind == "repair" and rng.random() < lamarck_p:
                c = repair(c)                # regula 5% (Orvosh & Davis): uneori scriem reparația înapoi
            nxt.append(c)
        pop = nxt
    feas = sum(1 for x in pop if kind in ("decoder", "repair") or weight(x) <= CAP) / pop_size
    return best_feasible, feas

if __name__ == "__main__":
    opt = dp_optimum(W, V, CAP)
    print(f"{N} obiecte, capacitate {CAP}, optim (programare dinamică) = {opt}")
    names = {"death": "pedeapsa cu moartea", "pen_lin": "penalizare liniară", "pen_sq": "penalizare pătratică",
             "repair": "reparare lacomă (5% Lamarck)", "decoder": "decodificator (permutare)"}
    for k, label in names.items():
        res = [ga(k, seed=s) for s in range(10)]
        vals = [r[0] for r in res]
        print(f"  {label:30s} medie={statistics.mean(vals):7.1f} ({100*statistics.mean(vals)/opt:5.1f}% din optim)"
              f"  max={max(vals)}  fezabili în pop. finală={100*statistics.mean(r[1] for r in res):5.1f}%")
