# Cod "generat de un asistent AI" la promptul: "Scrie A* pe grilă în Python".
# SARCINA: găsiți cel puțin 4 probleme, explicați efectul fiecăreia și scrieți teste care le demonstrează.
import heapq

def astar(problem):
    frontier = [(0, problem.initial)]
    g = {problem.initial: 0}
    parent = {problem.initial: None}
    visited = set()
    while frontier:
        f, s = heapq.heappop(frontier)
        visited.add(s)
        for a, s2 in problem.actions(s):
            if problem.is_goal(s2):
                parent[s2] = s
                return s2, parent
            if s2 in visited:
                continue
            g[s2] = g[s] + problem.cost(s, a, s2)
            parent[s2] = s
            h = ((s2[0]-problem.goal[0])**2 + (s2[1]-problem.goal[1])**2)
            heapq.heappush(frontier, (g[s2] + h, s2))
    return None
