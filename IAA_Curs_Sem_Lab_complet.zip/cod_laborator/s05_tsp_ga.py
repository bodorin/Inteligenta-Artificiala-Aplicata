"""AG cu permutări în DEAP: problema comis-voiajorului (TSP) cu 30 de orașe.
Comparație OX vs PMX și mutație prin inversiune vs interschimbare.  Rulare: python s05_tsp_ga.py"""
import random, math, statistics
from deap import base, creator, tools, algorithms

def cities(n=30, seed=42):
    r = random.Random(seed)
    return [(r.uniform(0, 100), r.uniform(0, 100)) for _ in range(n)]
C = cities()
D = [[math.dist(a, b) for b in C] for a in C]
def tour_len(t):
    return (sum(D[t[i]][t[i - 1]] for i in range(len(t))),)

def mut_inversion(ind):                  # inversează un segment = o mutare 2-opt aleatoare
    i, j = sorted(random.sample(range(len(ind) + 1), 2))
    ind[i:j] = ind[i:j][::-1]
    return (ind,)

creator.create("FitTSP", base.Fitness, weights=(-1.0,))
creator.create("Tour", list, fitness=creator.FitTSP)

def run(cx="ox", mut="inv", seed=0, mu=150, ngen=400):
    random.seed(seed)
    tb = base.Toolbox()
    tb.register("indices", random.sample, range(len(C)), len(C))
    tb.register("individual", tools.initIterate, creator.Tour, tb.indices)
    tb.register("population", tools.initRepeat, list, tb.individual)
    tb.register("evaluate", tour_len)
    tb.register("mate", tools.cxOrdered if cx == "ox" else tools.cxPartialyMatched)   # numele DEAP: „Partialy”
    tb.register("mutate", mut_inversion if mut == "inv" else tools.mutShuffleIndexes, **({} if mut == "inv" else {"indpb": 0.05}))
    tb.register("select", tools.selTournament, tournsize=3)
    pop, hof = tb.population(n=mu), tools.HallOfFame(1)
    algorithms.eaSimple(pop, tb, cxpb=0.7, mutpb=0.3, ngen=ngen, halloffame=hof, verbose=False)
    return hof[0].fitness.values[0], list(hof[0])

def two_opt(t):
    """Căutare locală 2-opt până la optim local – reper de comparație (și operator de „memetizare”)."""
    t, improved = t[:], True
    while improved:
        improved = False
        for i in range(1, len(t) - 1):
            for j in range(i + 1, len(t)):
                a, b, c, d = t[i - 1], t[i], t[j], t[(j + 1) % len(t)]
                if D[a][c] + D[b][d] < D[a][b] + D[c][d] - 1e-9:
                    t[i:j + 1] = reversed(t[i:j + 1]); improved = True
    return t

if __name__ == "__main__":
    print("TSP 30 de orașe, 150 indivizi × 400 generații, 5 rulări")
    for cx in ("ox", "pmx"):
        for mut in ("inv", "shuffle"):
            res = [run(cx, mut, seed=s)[0] for s in range(5)]
            print(f"  {cx.upper():3s} + {'inversiune' if mut=='inv' else 'interschimbări':14s} medie={statistics.mean(res):7.1f}  min={min(res):7.1f}")
    r = random.Random(1)
    res = [tour_len(two_opt(r.sample(range(30), 30)))[0] for _ in range(5)]
    print(f"  2-opt din 5 starturi aleatoare      medie={statistics.mean(res):7.1f}  min={min(res):7.1f}")
    best, tour = run("pmx", "shuffle", seed=0)
    print(f"  PMX+interschimbări, seed 0: {best:.1f}  ->  după 2-opt (pas memetic): {tour_len(two_opt(tour))[0]:.1f}")
