;; Transport aerian de marfă (Russell & Norvig, §11.1) – PDDL cu tipuri
(define (domain air-cargo)
  (:requirements :strips :typing)
  (:types cargo plane airport)
  (:predicates (at-c ?c - cargo ?a - airport) (at-p ?p - plane ?a - airport)
               (in ?c - cargo ?p - plane))
  (:action load
    :parameters (?c - cargo ?p - plane ?a - airport)
    :precondition (and (at-c ?c ?a) (at-p ?p ?a))
    :effect (and (not (at-c ?c ?a)) (in ?c ?p)))
  (:action unload
    :parameters (?c - cargo ?p - plane ?a - airport)
    :precondition (and (in ?c ?p) (at-p ?p ?a))
    :effect (and (at-c ?c ?a) (not (in ?c ?p))))
  (:action fly
    :parameters (?p - plane ?from - airport ?to - airport)
    :precondition (at-p ?p ?from)
    :effect (and (not (at-p ?p ?from)) (at-p ?p ?to))))
