"""Agent de căutare ONLINE (LRTA*) într-un mediu NECUNOSCUT.
Agentul nu cunoaște harta: la fiecare pas percepe doar vecinii accesibili ai celulei curente,
acționează imediat și își actualizează estimarea H(s) a costului până la țintă.
Rulare: python s01_lrta.py"""
from s01_grid_search import GRID, GridProblem, bfs

class LRTAStarAgent:
    def __init__(self, goal):
        self.goal = goal
        self.H = {}                         # estimările învățate H(s)
        self.result = {}                    # modelul de tranziție învățat: (s, a) -> s'
        self.s = self.a = None
    def h(self, s):
        return abs(s[0] - self.goal[0]) + abs(s[1] - self.goal[1])
    def lrta_cost(self, s, s2):
        if s2 is None:                      # rezultat încă necunoscut: optimism față de necunoscut
            return self.h(s)
        return 1 + self.H.get(s2, self.h(s2))
    def __call__(self, s, available_actions):
        if s == self.goal:
            return None
        self.H.setdefault(s, self.h(s))
        if self.s is not None:
            self.result[(self.s, self.a)] = s
            # actualizare: H(s_prev) = min_b cost(s_prev, b)
            self.H[self.s] = min(self.lrta_cost(self.s, self.result.get((self.s, b)))
                                 for b in self.prev_actions)
        self.a = min(available_actions,
                     key=lambda b: self.lrta_cost(s, self.result.get((s, b))))
        self.s, self.prev_actions = s, list(available_actions)
        return self.a

def explore(problem, agent, max_steps=2000):
    """Mediul: execută acțiunea și îi întoarce agentului doar percepția locală."""
    s, steps, trace = problem.initial, 0, [problem.initial]
    while steps < max_steps:
        moves = dict(problem.actions(s))    # percepție locală: ce direcții sunt libere
        a = agent(s, list(moves))
        if a is None:
            return steps, trace
        s = moves[a]; steps += 1; trace.append(s)
    return None, trace

if __name__ == "__main__":
    P = GridProblem(GRID)
    opt_path, _ = bfs(P)   # LRTA* de aici numără pașii (cost unitar)
    agent = LRTAStarAgent(P.goal)
    for trial in range(1, 6):              # rulări repetate: agentul își păstrează H (învață)
        steps, _ = explore(P, agent)
        print(f"încercarea {trial}: {steps} pași  (minimul offline, cu harta cunoscută: {len(opt_path)-1})")
        agent.s = agent.a = None
