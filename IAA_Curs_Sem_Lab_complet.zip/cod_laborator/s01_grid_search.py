"""Agenți de căutare pe grilă: BFS, DFS, UCS, Greedy și A*.
'#' = zid, '~' = mlaștină (cost 5), 'S' = start, 'G' = țintă.  Rulare: python s01_grid_search.py"""
import heapq
from collections import deque

GRID = """
S....#........
.##..#..~~~...
..#..#..~~~.#.
..#.....~~~.#.
..####..#...#.
.....#..#..##G
""".strip().splitlines()

class GridProblem:
    """Formularea problemei: stare inițială, acțiuni, model de tranziție, test de scop, cost."""
    MOVES = {"N": (-1, 0), "S": (1, 0), "V": (0, -1), "E": (0, 1)}
    def __init__(self, grid):
        self.grid = grid
        self.R, self.C = len(grid), len(grid[0])
        for r, row in enumerate(grid):
            for c, ch in enumerate(row):
                if ch == "S": self.initial = (r, c)
                if ch == "G": self.goal = (r, c)
    def actions(self, s):
        r, c = s
        for a, (dr, dc) in self.MOVES.items():
            nr, nc = r + dr, c + dc
            if 0 <= nr < self.R and 0 <= nc < self.C and self.grid[nr][nc] != "#":
                yield a, (nr, nc)
    def cost(self, s, a, s2):
        return 5 if self.grid[s2[0]][s2[1]] == "~" else 1
    def is_goal(self, s):
        return s == self.goal
    def h(self, s):                       # distanța Manhattan: admisibilă și consistentă (cost minim pe pas = 1)
        return abs(s[0] - self.goal[0]) + abs(s[1] - self.goal[1])

def path_from(parent, s):
    path = [s]
    while parent[s] is not None:
        s = parent[s]; path.append(s)
    return path[::-1]

def bfs(p):
    frontier, parent, expanded = deque([p.initial]), {p.initial: None}, 0
    while frontier:
        s = frontier.popleft(); expanded += 1
        if p.is_goal(s): return path_from(parent, s), expanded
        for a, s2 in p.actions(s):
            if s2 not in parent:
                parent[s2] = s; frontier.append(s2)
    return None, expanded

def dfs(p):
    frontier, parent, expanded, seen = [p.initial], {p.initial: None}, 0, set()
    while frontier:
        s = frontier.pop()
        if s in seen: continue
        seen.add(s); expanded += 1
        if p.is_goal(s): return path_from(parent, s), expanded
        for a, s2 in p.actions(s):
            if s2 not in seen:
                parent[s2] = s; frontier.append(s2)
    return None, expanded

def best_first(p, f):
    """Schema generală best-first; f(g, s) dă prioritatea. UCS: f=g; Greedy: f=h; A*: f=g+h."""
    g = {p.initial: 0}; parent = {p.initial: None}
    frontier = [(f(0, p.initial), 0, p.initial)]; expanded = 0; tie = 0
    closed = set()
    while frontier:
        _, _, s = heapq.heappop(frontier)
        if s in closed: continue          # intrare învechită în coadă
        closed.add(s); expanded += 1
        if p.is_goal(s): return path_from(parent, s), expanded   # testul de scop la EXTRAGERE!
        for a, s2 in p.actions(s):
            g2 = g[s] + p.cost(s, a, s2)
            if s2 not in g or g2 < g[s2]:
                g[s2] = g2; parent[s2] = s; tie += 1
                heapq.heappush(frontier, (f(g2, s2), tie, s2))
    return None, expanded

def path_cost(p, path):
    return sum(p.cost(path[i], None, path[i + 1]) for i in range(len(path) - 1))

if __name__ == "__main__":
    P = GridProblem(GRID)
    algos = {
        "BFS": lambda: bfs(P),
        "DFS": lambda: dfs(P),
        "UCS": lambda: best_first(P, lambda g, s: g),
        "Greedy": lambda: best_first(P, lambda g, s: P.h(s)),
        "A*": lambda: best_first(P, lambda g, s: g + P.h(s)),
    }
    print(f"{'Algoritm':8s} {'expandate':>9s} {'pași':>5s} {'cost':>5s}")
    for name, run in algos.items():
        path, exp = run()
        print(f"{name:8s} {exp:9d} {len(path)-1:5d} {path_cost(P, path):5d}")
