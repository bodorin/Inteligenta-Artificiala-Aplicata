"""Planificare cu timp și resurse: metoda drumului critic (CPM) și programare cu resurse limitate.
Exemplul „asamblarea a două mașini” (Russell & Norvig, §11.6.1).   Rulare: python s04_schedule.py"""
from itertools import permutations

TASKS = {   # nume: (durată, predecesori, resursa reutilizabilă folosită)
    "AddEngine1": (30, [], "EngineHoist"),
    "AddWheels1": (30, ["AddEngine1"], "WheelStation"),
    "Inspect1":   (10, ["AddWheels1"], "Inspector"),
    "AddEngine2": (60, [], "EngineHoist"),
    "AddWheels2": (15, ["AddEngine2"], "WheelStation"),
    "Inspect2":   (10, ["AddWheels2"], "Inspector"),
}
CAPACITY = {"EngineHoist": 1, "WheelStation": 1, "Inspector": 2}

def topo(tasks):
    order, seen = [], set()
    def visit(t):
        if t in seen: return
        seen.add(t)
        for p in tasks[t][1]: visit(p)
        order.append(t)
    for t in tasks: visit(t)
    return order

def cpm(tasks):
    """ES = cel mai devreme start, LS = cel mai târziu start; slack = LS − ES; drum critic: slack = 0."""
    order = topo(tasks)
    ES = {}
    for t in order:
        ES[t] = max((ES[p] + tasks[p][0] for p in tasks[t][1]), default=0)
    makespan = max(ES[t] + tasks[t][0] for t in tasks)
    succ = {t: [u for u in tasks if t in tasks[u][1]] for t in tasks}
    LS = {}
    for t in reversed(order):
        LS[t] = min((LS[u] for u in succ[t]), default=makespan) - tasks[t][0]
    return ES, LS, makespan

def serial_sgs(tasks, capacity, priority):
    """Schemă serială de generare a programului: la fiecare pas alege, după prioritate, o sarcină
    ai cărei predecesori sunt programați și o plasează la cel mai devreme moment fezabil (precedență + resurse)."""
    start, done = {}, set()
    while len(done) < len(tasks):
        eligible = [t for t in tasks if t not in done and all(p in done for p in tasks[t][1])]
        t = min(eligible, key=priority)
        dur, preds, res = tasks[t]
        s = max((start[p] + tasks[p][0] for p in preds), default=0)
        while True:   # avansăm s până când resursa e liberă pe tot intervalul [s, s+dur)
            busy = [(start[u], start[u] + tasks[u][0]) for u in done if tasks[u][2] == res]
            if all(sum(1 for a, b in busy if a <= x < b) < capacity[res] for x in range(s, s + dur)):
                break
            s += 1
        start[t] = s; done.add(t)
    return start, max(start[t] + tasks[t][0] for t in tasks)

def best_order(tasks, capacity):
    """Optimul prin enumerarea tuturor ordinilor de programare (fezabil doar pentru instanțe mici!)."""
    best = None
    for perm in permutations(tasks):
        rank = {t: i for i, t in enumerate(perm)}
        if any(rank[p] > rank[t] for t in tasks for p in tasks[t][1]):
            continue
        st, mk = serial_sgs(tasks, capacity, lambda t: rank[t])
        if best is None or mk < best[1]:
            best = (st, mk)
    return best

def gantt(start, tasks, scale=5):
    for t in sorted(start, key=start.get):
        s, d = start[t], tasks[t][0]
        print(f"  {t:11s} {s:4d}–{s+d:<4d} |" + " " * (s // scale) + "█" * (d // scale))

if __name__ == "__main__":
    ES, LS, mk = cpm(TASKS)
    print(f"CPM fără resurse: durata minimă = {mk} min")
    for t in topo(TASKS):
        print(f"  {t:11s} ES={ES[t]:3d} LS={LS[t]:3d} slack={LS[t]-ES[t]:3d}" + ("  <- critic" if LS[t] == ES[t] else ""))
    st, mk2 = serial_sgs(TASKS, CAPACITY, priority=lambda t: (LS[t] - ES[t], ES[t]))
    print(f"\nCu resurse, euristica „slack minim”: {mk2} min"); gantt(st, TASKS)
    st, mk3 = best_order(TASKS, CAPACITY)
    print(f"\nCu resurse, optim (enumerare): {mk3} min"); gantt(st, TASKS)
