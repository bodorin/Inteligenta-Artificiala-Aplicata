"""Comparație: A* (h_add) vs GraphPlan vs SATPlan pe aceleași probleme STRIPS.
Necesită fișierele s02_strips.py, s03_graphplan.py, s03_satplan.py în același director."""
import time, io, contextlib
import s02_strips as S, s03_graphplan as G, s03_satplan as SP

def timed(f):
    t = time.perf_counter(); r = f(); return r, time.perf_counter() - t

problems = {
    "Sussman": S.blocks_world(S.towers([["A", "C"], ["B"]]), {"on(A,B)", "on(B,C)"}, "ABC"),
    "Inversare 5": S.blocks_world(S.towers([list("ABCDE")]), {"on(D,E)", "on(C,D)", "on(B,C)", "on(A,B)"}, "ABCDE"),
}
print(f"{'Problemă':12s} | {'A* h_add':>16s} | {'GraphPlan':>16s} | {'SATPlan':>16s}")
for name, p in problems.items():
    (plan, _, _), t1 = timed(lambda: S.forward_search(p, S.h_add))
    init, goal, acts = G.from_strips(p)
    (gp, _), t2 = timed(lambda: G.graphplan(init, goal, acts))
    with contextlib.redirect_stdout(io.StringIO()):
        sp, t3 = timed(lambda: SP.satplan(p))
    print(f"{name:12s} | {len(plan):3d} acț {t1*1000:7.1f} ms | {len(gp):3d} niv {t2*1000:7.1f} ms | T={sp[0]:3d} {t3*1000:7.1f} ms")
