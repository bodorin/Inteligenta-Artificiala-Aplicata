"""Lumea aspiratorului (Russell & Norvig, cap. 2) – agent reflex simplu vs. agent bazat pe model.
Rulare: python s01_vacuum.py"""
import random

class VacuumWorld:
    """Mediu cu n camere pe o linie. Murdăria poate reapărea cu probabilitatea p_dirt."""
    def __init__(self, n=2, p_dirt=0.0, seed=0):
        self.rng = random.Random(seed)
        self.n, self.p_dirt = n, p_dirt
        self.dirty = [self.rng.random() < 0.5 for _ in range(n)]
        self.pos = self.rng.randrange(n)
        self.score = 0

    def percept(self):                      # observabilitate parțială: doar camera curentă
        return self.pos, self.dirty[self.pos]

    def execute(self, action):
        if action == "Suck":
            if self.dirty[self.pos]:
                self.score += 10            # măsura de performanță: +10 pentru fiecare cameră curățată
            self.dirty[self.pos] = False
        elif action == "Left" and self.pos > 0:
            self.pos -= 1; self.score -= 1  # -1 pentru fiecare deplasare (consum de energie)
        elif action == "Right" and self.pos < self.n - 1:
            self.pos += 1; self.score -= 1
        for i in range(self.n):             # mediu dinamic: murdăria poate reapărea
            if self.rng.random() < self.p_dirt:
                self.dirty[i] = True

def simple_reflex_agent(percept):
    """Regulă condiție-acțiune: decide DOAR pe baza percepției curente."""
    pos, dirty = percept
    if dirty:
        return "Suck"
    return "Right" if pos == 0 else "Left"   # pentru n = 2

class ModelBasedAgent:
    """Păstrează o stare internă (ce camere știe că sunt curate) și se oprește când totul e curat."""
    def __init__(self, n):
        self.known_clean = [False] * n
        self.direction = "Right"
    def __call__(self, percept):
        pos, dirty = percept
        if dirty:
            self.known_clean[pos] = True
            return "Suck"
        self.known_clean[pos] = True
        if all(self.known_clean):
            return "NoOp"                    # nu mai consumă energie inutil
        n = len(self.known_clean)
        if pos == n - 1: self.direction = "Left"
        if pos == 0: self.direction = "Right"
        return self.direction

def run(agent, env, steps=20, verbose=False):
    for t in range(steps):
        p = env.percept()
        a = agent(p)
        env.execute(a)
        if verbose:
            print(f"t={t:2d} percepție={p} acțiune={a:5s} scor={env.score}")
    return env.score

if __name__ == "__main__":
    for p_dirt in (0.0, 0.05):
        r1 = sum(run(simple_reflex_agent, VacuumWorld(2, p_dirt, s)) for s in range(100)) / 100
        r2 = sum(run(ModelBasedAgent(2), VacuumWorld(2, p_dirt, s)) for s in range(100)) / 100
        print(f"p_dirt={p_dirt:.2f}  reflex simplu: {r1:6.2f}   bazat pe model: {r2:6.2f}")
