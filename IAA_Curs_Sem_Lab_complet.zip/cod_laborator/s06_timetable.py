"""Orar universitar cu AG în DEAP: restricții tari (penalizate puternic) și slabe (de calitate).
Cromozom: pentru fiecare activitate, un întreg = (interval orar, sală).   Rulare: python s06_timetable.py"""
import random, statistics
from collections import Counter
from deap import base, creator, tools, algorithms

DAYS, PER_DAY = 4, 3                         # 4 zile × 3 intervale (8–10, 10–12, 12–14)
SLOTS = DAYS * PER_DAY
ROOMS = {"S1": 30, "S2": 60, "Amf": 120}
ROOM_LIST = list(ROOMS)
# activitate: (nume, profesor, grupă, nr. studenți)
EVENTS = [
    ("IA-curs", "Popescu", "M1", 55), ("IA-lab-a", "Popescu", "M1a", 28), ("IA-lab-b", "Popescu", "M1b", 27),
    ("MVD-curs", "Ionescu", "M1", 55), ("MVD-lab-a", "Ionescu", "M1a", 28), ("MVD-lab-b", "Georgescu", "M1b", 27),
    ("Grafica-curs", "Marin", "M1", 55), ("Grafica-lab-a", "Marin", "M1a", 28), ("Grafica-lab-b", "Marin", "M1b", 27),
    ("Retele-curs", "Dobre", "M2", 50), ("Retele-lab", "Dobre", "M2", 50), ("VR-curs", "Ionescu", "M2", 50),
    ("VR-lab", "Georgescu", "M2", 50), ("Etica-curs", "Stan", "M1+M2", 105), ("Seminar-cerc", "Stan", "M2", 50),
    ("Proiect-M1", "Popescu", "M1", 55),
]
UNAVAILABLE = {"Popescu": {0, 1, 2}, "Stan": {9, 10, 11}}   # Popescu nu poate luni; Stan nu poate joi

def groups_of(g):                            # M1 include M1a și M1b; M1+M2 include tot
    return {"M1": {"M1", "M1a", "M1b"}, "M1a": {"M1", "M1a"}, "M1b": {"M1", "M1b"},
            "M2": {"M2"}, "M1+M2": {"M1", "M1a", "M1b", "M2"}}[g]

def decode(ind):
    return [(gene // len(ROOMS), ROOM_LIST[gene % len(ROOMS)]) for gene in ind]

def violations(ind):
    """Întoarce (restricții tari încălcate, cost slab)."""
    sched, hard, soft = decode(ind), 0, 0
    room_use = Counter(sched)
    hard += sum(c - 1 for c in room_use.values() if c > 1)                         # H1: sală dublu ocupată
    for i in range(len(EVENTS)):
        s, r = sched[i]; name, prof, grp, size = EVENTS[i]
        if size > ROOMS[r]: hard += 1                                              # H2: capacitate
        if s in UNAVAILABLE.get(prof, ()): hard += 1                               # H3: indisponibilitate
        if size < ROOMS[r] / 3: soft += 1                                          # S3: sală mult prea mare
        for j in range(i + 1, len(EVENTS)):
            if sched[j][0] != s: continue
            if EVENTS[j][1] == prof: hard += 1                                     # H4: profesor în două locuri
            if groups_of(grp) & groups_of(EVENTS[j][2]): hard += 1                 # H5: grupă în două locuri
    for g in ("M1a", "M1b", "M2"):                                                 # restricții slabe, pe grupe
        days = Counter(sched[i][0] // PER_DAY for i in range(len(EVENTS)) if g in groups_of(EVENTS[i][2]))
        soft += sum(max(0, c - 2) for c in days.values())                          # S1: peste 2 activități/zi
        soft += sum(1 for i in range(len(EVENTS))
                    if g in groups_of(EVENTS[i][2]) and sched[i][0] % PER_DAY == 2)  # S2: interval târziu
    return hard, soft

def fitness(ind):
    h, s = violations(ind)
    return (1000 * h + s,)                    # penalizare: o restricție tare „costă” cât 1000 de restricții slabe

creator.create("FitTT", base.Fitness, weights=(-1.0,))
creator.create("Timetable", list, fitness=creator.FitTT)

def smart_mutation(ind, p_smart=0.5):
    """Mutație „inteligentă” (hibrid cu căutare locală): mută o activitate în poziția care minimizează costul."""
    i = random.randrange(len(ind))
    if random.random() < p_smart:
        best, best_f = ind[i], fitness(ind)[0]
        for gene in random.sample(range(SLOTS * len(ROOMS)), 15):
            old = ind[i]; ind[i] = gene; f = fitness(ind)[0]
            if f < best_f: best, best_f = gene, f
            ind[i] = old
        ind[i] = best
    else:
        ind[i] = random.randrange(SLOTS * len(ROOMS))
    return (ind,)

def run(seed=0, smart=True, mu=80, ngen=150):
    random.seed(seed)
    tb = base.Toolbox()
    tb.register("gene", random.randrange, SLOTS * len(ROOMS))
    tb.register("individual", tools.initRepeat, creator.Timetable, tb.gene, len(EVENTS))
    tb.register("population", tools.initRepeat, list, tb.individual)
    tb.register("evaluate", fitness)
    tb.register("mate", tools.cxUniform, indpb=0.5)
    tb.register("mutate", smart_mutation if smart else (lambda ind: smart_mutation(ind, 0.0)))
    tb.register("select", tools.selTournament, tournsize=3)
    pop, hof = tb.population(n=mu), tools.HallOfFame(1)
    algorithms.eaSimple(pop, tb, cxpb=0.7, mutpb=0.4, ngen=ngen, halloffame=hof, verbose=False)
    return hof[0]

def show(ind):
    grid = {}
    for (s, r), e in zip(decode(ind), EVENTS):
        grid.setdefault((s, r), []).append(e[0])
    zile = ["Lu", "Ma", "Mi", "Jo"]
    print("        " + "".join(f"{r:>16s}" for r in ROOM_LIST))
    for s in range(SLOTS):
        print(f"{zile[s // PER_DAY]} {8 + 2 * (s % PER_DAY):2d}-{10 + 2 * (s % PER_DAY):2d}" +
              "".join(f"{','.join(grid.get((s, r), ['·'])):>16s}" for r in ROOM_LIST))

if __name__ == "__main__":
    for smart in (False, True):
        res = [violations(run(seed=s, smart=smart)) for s in range(5)]
        print(f"{'mutație inteligentă' if smart else 'mutație aleatoare  '}: "
              f"restricții tari încălcate (5 rulări) = {[h for h, _ in res]}, cost slab = {[s for _, s in res]}")
    best = run(seed=0, smart=True)
    print("\nCel mai bun orar (seed 0): tari =", violations(best)[0], " slabe =", violations(best)[1])
    show(best)
