"""Graful de planificare și algoritmul GraphPlan (Blum & Furst, 1997), cu euristici extrase din graf.
Literali: 'p' sau '¬p'. Acțiunile pot avea precondiții negative (ca în exemplele din AIMA).
Rulare: python s03_graphplan.py"""
from itertools import combinations

def neg(l):
    return l[1:] if l.startswith("¬") else "¬" + l

class Act:
    def __init__(self, name, pre, eff, noop=False):
        self.name, self.pre, self.eff, self.noop = name, frozenset(pre), frozenset(eff), noop
    def __repr__(self):
        return self.name

def closed_world(init, fluents):
    """Ipoteza lumii închise: fluenții care nu apar în starea inițială sunt falși."""
    return frozenset(init) | {neg(f) for f in fluents if f not in init}

class PlanningGraph:
    def __init__(self, init, actions):
        self.S = [frozenset(init)]          # niveluri de literali S0, S1, ...
        self.A = []                         # niveluri de acțiuni A0, A1, ...
        self.mS = [set()]                   # mutex între literali (perechi frozenset)
        self.mA = []
        self.actions = actions

    def expand(self):
        S, mS = self.S[-1], self.mS[-1]
        acts = [a for a in self.actions
                if a.pre <= S and not any(frozenset(p) in mS for p in combinations(a.pre, 2))]
        acts += [Act(f"noop[{l}]", {l}, {l}, noop=True) for l in sorted(S)]   # acțiuni de persistență
        mA = set()
        for a, b in combinations(acts, 2):
            if (any(neg(e) in b.eff for e in a.eff) or                           # efecte inconsistente
                any(neg(e) in b.pre for e in a.eff) or any(neg(e) in a.pre for e in b.eff) or  # interferență
                any(frozenset((p, q)) in mS for p in a.pre for q in b.pre)):    # nevoi concurente
                mA.add(frozenset((a, b)))
        S2 = frozenset(e for a in acts for e in a.eff)
        achievers = {l: [a for a in acts if l in a.eff] for l in S2}
        mS2 = set()
        for p, q in combinations(S2, 2):
            if p == neg(q) or all(frozenset((a, b)) in mA                         # negație sau suport inconsistent
                                  for a in achievers[p] for b in achievers[q] if a is not b) \
                    and not set(achievers[p]) & set(achievers[q]):
                mS2.add(frozenset((p, q)))
        self.A.append(acts); self.mA.append(mA); self.S.append(S2); self.mS.append(mS2)

    def leveled_off(self):
        return len(self.S) > 1 and self.S[-1] == self.S[-2] and self.mS[-1] == self.mS[-2]

    def goals_ok(self, goals, i):
        return goals <= self.S[i] and not any(frozenset(p) in self.mS[i] for p in combinations(goals, 2))

    # ---------- euristici din graful de planificare ----------
    def level(self, l):
        return next((i for i, S in enumerate(self.S) if l in S), float("inf"))

def build_until_level_off(init, actions):
    pg = PlanningGraph(init, actions)
    while not pg.leveled_off():
        pg.expand()
    return pg

def heuristics(init, goals, actions):
    pg = build_until_level_off(init, actions)
    lv = [pg.level(g) for g in goals]
    set_level = next((i for i in range(len(pg.S)) if pg.goals_ok(goals, i)), float("inf"))
    return {"max-level": max(lv), "level-sum": sum(lv), "set-level": set_level}

# ---------- GraphPlan: extinde graful, apoi extrage soluția înapoi ----------
def graphplan(init, goals, actions, max_levels=50):
    goals = frozenset(goals)
    pg, nogoods, prev_ng = PlanningGraph(init, actions), set(), None
    for n in range(max_levels):
        if pg.goals_ok(goals, n):
            plan = extract(pg, goals, n, nogoods)
            if plan is not None:
                return plan, pg
            # Terminare (Blum & Furst): graful s-a stabilizat și nu au apărut nogood-uri noi
            ng_last = frozenset(g for (i, g) in nogoods if i == n)
            if pg.leveled_off() and ng_last == prev_ng:
                return None, pg
            prev_ng = ng_last
        elif pg.leveled_off():
            return None, pg                   # scopurile nu apar (sau rămân mutex) nici după stabilizare
        pg.expand()
    return None, pg

def extract(pg, goals, i, nogoods):
    if i == 0:
        return [] if goals <= pg.S[0] else None
    if (i, goals) in nogoods:
        return None
    acts, mA = pg.A[i - 1], pg.mA[i - 1]
    goal_list = sorted(goals)

    def choose(k, chosen, covered):        # căutare cu revenire: alegem acțiuni non-mutex care acoperă scopurile
        if k == len(goal_list):
            sub = frozenset(p for a in chosen for p in a.pre)
            rest = extract(pg, sub, i - 1, nogoods)
            return None if rest is None else rest + [[a for a in chosen if not a.noop]]
        g = goal_list[k]
        if g in covered:
            return choose(k + 1, chosen, covered)
        cands = sorted((a for a in acts if g in a.eff), key=lambda a: not a.noop)  # preferăm no-op-urile
        for a in cands:
            if all(frozenset((a, b)) not in mA for b in chosen):
                r = choose(k + 1, chosen + [a], covered | a.eff)
                if r is not None:
                    return r
        return None

    r = choose(0, [], frozenset())
    if r is None:
        nogoods.add((i, goals))
    return r

# ---------- exemple din Russell & Norvig ----------
def cake():
    acts = [Act("Eat(Cake)", {"Have(Cake)"}, {"¬Have(Cake)", "Eaten(Cake)"}),
            Act("Bake(Cake)", {"¬Have(Cake)"}, {"Have(Cake)"})]
    init = closed_world({"Have(Cake)"}, ["Have(Cake)", "Eaten(Cake)"])
    return init, {"Have(Cake)", "Eaten(Cake)"}, acts

def spare_tire():
    F = ["At(Spare,Trunk)", "At(Spare,Axle)", "At(Spare,Ground)", "At(Flat,Axle)", "At(Flat,Ground)", "At(Flat,Trunk)"]
    acts = []
    for obj in ("Spare", "Flat"):
        for loc in ("Trunk", "Axle"):
            acts.append(Act(f"Remove({obj},{loc})", {f"At({obj},{loc})"}, {f"¬At({obj},{loc})", f"At({obj},Ground)"}))
        acts.append(Act(f"PutOn({obj},Axle)", {f"At({obj},Ground)", "¬At(Flat,Axle)", "¬At(Spare,Axle)"},
                        {f"¬At({obj},Ground)", f"At({obj},Axle)"}))
    acts.append(Act("LeaveOvernight", set(), {neg(f) for f in F}))
    init = closed_world({"At(Spare,Trunk)", "At(Flat,Axle)"}, F)
    return init, {"At(Spare,Axle)"}, acts

if __name__ == "__main__":
    for name, (init, goals, acts) in [("Tortul", cake()), ("Roata de rezervă", spare_tire())]:
        plan, pg = graphplan(init, goals, acts)
        print(f"== {name}: plan pe {len(plan)} niveluri ->", plan)
        print("   euristici în s0:", heuristics(init, frozenset(goals), acts))
        for i in range(len(pg.A)):
            real = [a for a in pg.A[i] if not a.noop]
            print(f"   A{i}: {real}   |S{i+1}|={len(pg.S[i+1])}  mutex literali={len(pg.mS[i+1])}")

def from_strips(p):
    """Conversie din reprezentarea din s02_strips.py (ADD/DEL) în literali pozitivi/negativi."""
    fluents = set(p.init) | set(p.goal) | {f for a in p.actions for f in a.pre | a.add | a.dele}
    acts = [Act(a.name, a.pre, set(a.add) | {neg(d) for d in a.dele - a.add}) for a in p.actions]
    return closed_world(set(p.init), fluents), frozenset(p.goal), acts
