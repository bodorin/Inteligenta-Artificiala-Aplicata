;; Două colete, două avioane: CND = Constanța, OTP = București, CLJ = Cluj
(define (problem cargo-ro)
  (:domain air-cargo)
  (:objects C1 C2 - cargo  P1 P2 - plane  CND OTP CLJ - airport)
  (:init (at-c C1 CND) (at-c C2 CLJ) (at-p P1 CND) (at-p P2 CLJ))
  (:goal (and (at-c C1 CLJ) (at-c C2 OTP))))
