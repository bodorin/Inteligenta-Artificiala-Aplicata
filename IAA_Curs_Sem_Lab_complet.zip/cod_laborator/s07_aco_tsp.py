"""Optimizarea prin colonii de furnici (ACO) pentru TSP: Ant System și MAX-MIN Ant System.
Aceeași instanță ca în ședința 5 (30 de orașe, seed 42), pentru comparația cu AG.   Rulare: python s07_aco_tsp.py"""
import random, math, statistics, time

def cities(n=30, seed=42):
    r = random.Random(seed)
    return [(r.uniform(0, 100), r.uniform(0, 100)) for _ in range(n)]
C = cities(); N = len(C)
D = [[math.dist(a, b) or 1e-9 for b in C] for a in C]

def tour_len(t):
    return sum(D[t[i]][t[i - 1]] for i in range(N))

def nearest_neighbour(start=0):
    t, left = [start], set(range(N)) - {start}
    while left:
        nxt = min(left, key=lambda j: D[t[-1]][j]); t.append(nxt); left.remove(nxt)
    return t

def aco(n_ants=30, iters=200, alpha=1.0, beta=3.0, rho=0.1, Q=100.0, mmas=False, seed=0):
    """Ant System (Dorigo, 1992); cu mmas=True: MAX-MIN AS (Stützle & Hoos, 2000)."""
    rng = random.Random(seed)
    L_nn = tour_len(nearest_neighbour())
    tau_max = 1 / (rho * L_nn); tau_min = tau_max / (2 * N)
    tau = [[tau_max if mmas else 1.0 / L_nn] * N for _ in range(N)]     # feromon inițial
    eta = [[1.0 / D[i][j] for j in range(N)] for i in range(N)]         # vizibilitate (informație euristică)
    best_t, best_L, history = None, float("inf"), []
    for it in range(iters):
        tours = []
        for _ in range(n_ants):
            start = rng.randrange(N); t = [start]; unvisited = set(range(N)) - {start}
            while unvisited:
                i = t[-1]; cand = list(unvisited)
                w = [(tau[i][j] ** alpha) * (eta[i][j] ** beta) for j in cand]   # regula proporțională aleatoare
                r, acc = rng.random() * sum(w), 0.0
                for j, wj in zip(cand, w):
                    acc += wj
                    if acc >= r: break
                t.append(j); unvisited.remove(j)
            tours.append((tour_len(t), t))
        it_L, it_t = min(tours)
        if it_L < best_L: best_L, best_t = it_L, it_t
        for i in range(N):                                   # evaporare
            for j in range(N): tau[i][j] *= (1 - rho)
        depositors = [(best_L, best_t) if it % 10 == 0 else (it_L, it_t)] if mmas else tours
        for L, t in depositors:                              # depunere (MMAS: doar cea mai bună furnică)
            for k in range(N):
                a, b = t[k - 1], t[k]; d = (1.0 / L) if mmas else Q / L
                tau[a][b] += d; tau[b][a] += d
        if mmas:                                             # limite [τ_min, τ_max] contra stagnării
            tau_max = 1 / (rho * best_L); tau_min = tau_max / (2 * N)
            for i in range(N):
                for j in range(N): tau[i][j] = min(tau_max, max(tau_min, tau[i][j]))
        history.append(best_L)
    return best_L, best_t, history

if __name__ == "__main__":
    print(f"Vecinul cel mai apropiat: {tour_len(nearest_neighbour()):.1f}")
    for mm in (False, True):
        t0 = time.perf_counter()
        res = [aco(mmas=mm, seed=s)[0] for s in range(5)]
        print(f"{'MAX-MIN AS' if mm else 'Ant System'}: medie={statistics.mean(res):.1f}  min={min(res):.1f}  "
              f"timp/rulare={(time.perf_counter()-t0)/5:.1f}s   (30 furnici × 200 iterații = 6000 de tururi)")
    for beta in (0, 1, 5):
        print(f"  AS cu β={beta}: {aco(beta=beta, seed=0, iters=100)[0]:.1f}")
