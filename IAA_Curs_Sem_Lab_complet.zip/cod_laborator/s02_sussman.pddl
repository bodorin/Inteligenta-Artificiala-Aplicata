;; Anomalia lui Sussman: C este pe A, B pe masă. Scop: A pe B, B pe C.
(define (problem sussman)
  (:domain blocks)
  (:objects A B C - block)
  (:init (on C A) (ontable A) (ontable B) (clear C) (clear B) (handempty))
  (:goal (and (on A B) (on B C))))
