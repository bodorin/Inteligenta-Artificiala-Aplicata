"""Planificare STRIPS prin căutare în spațiul stărilor: progresie (înainte) și regresie (înapoi).
Euristici independente de domeniu: număr de scopuri nesatisfăcute, h_max, h_add (relaxarea listelor de ștergere).
Rulare: python s02_strips.py"""
import heapq, itertools, time
from collections import deque

class Action:
    """Acțiune STRIPS instanțiată (ground): precondiții, listă de adăugare, listă de ștergere."""
    def __init__(self, name, pre, add, dele, cost=1):
        self.name, self.pre, self.add, self.dele, self.cost = name, frozenset(pre), frozenset(add), frozenset(dele), cost
    def applicable(self, s):
        return self.pre <= s
    def apply(self, s):                       # RESULT(s, a) = (s − DEL(a)) ∪ ADD(a)
        return (s - self.dele) | self.add
    def __repr__(self):
        return self.name

class Problem:
    def __init__(self, init, goal, actions):
        self.init, self.goal, self.actions = frozenset(init), frozenset(goal), actions

# ---------- domeniul „lumea blocurilor” (instanțiere automată a schemelor de acțiuni) ----------
def blocks_world(init, goal, blocks):
    A = []
    for x in blocks:
        A.append(Action(f"pickup({x})", {f"clear({x})", f"ontable({x})", "handempty"},
                        {f"holding({x})"}, {f"clear({x})", f"ontable({x})", "handempty"}))
        A.append(Action(f"putdown({x})", {f"holding({x})"},
                        {f"clear({x})", f"ontable({x})", "handempty"}, {f"holding({x})"}))
        for y in blocks:
            if x == y: continue
            A.append(Action(f"unstack({x},{y})", {f"on({x},{y})", f"clear({x})", "handempty"},
                            {f"holding({x})", f"clear({y})"}, {f"on({x},{y})", f"clear({x})", "handempty"}))
            A.append(Action(f"stack({x},{y})", {f"holding({x})", f"clear({y})"},
                            {f"on({x},{y})", f"clear({x})", "handempty"}, {f"holding({x})", f"clear({y})"}))
    return Problem(init, goal, A)

def towers(stacks):
    """[['C','A'], ['B']] = A peste C pe masă; B pe masă  ->  mulțime de fluenți."""
    s = {"handempty"}
    for st in stacks:
        s.add(f"ontable({st[0]})"); s.add(f"clear({st[-1]})")
        for lo, hi in zip(st, st[1:]): s.add(f"on({hi},{lo})")
    return s

# ---------- euristici ----------
def h_goalcount(p, s):
    """Relaxare: ignoră precondițiile -> numărul de scopuri nesatisfăcute (nu e garantat admisibilă)."""
    return len(p.goal - s)

def _relaxed_costs(p, s, combine):
    """Costuri în problema relaxată (fără liste de ștergere), calculate prin punct fix."""
    cost = {f: 0 for f in s}
    changed = True
    while changed:
        changed = False
        for a in p.actions:
            if all(f in cost for f in a.pre):
                c = a.cost + (combine(cost[f] for f in a.pre) if a.pre else 0)
                for f in a.add:
                    if c < cost.get(f, float("inf")):
                        cost[f] = c; changed = True
    return cost

def h_max(p, s):                              # admisibilă
    c = _relaxed_costs(p, s, lambda xs: max(xs, default=0))
    return max((c.get(g, float("inf")) for g in p.goal), default=0)

def h_add(p, s):                              # informativă, dar NEadmisibilă (presupune independența subscopurilor)
    c = _relaxed_costs(p, s, sum)
    return sum(c.get(g, float("inf")) for g in p.goal)

# ---------- căutare înainte (progresie) ----------
def forward_search(p, h=None, weight=1):
    """h=None -> BFS; altfel A* (weight=1) sau Weighted A* (weight>1)."""
    t0, cnt = time.perf_counter(), itertools.count()
    start = p.init
    if h is None:
        frontier, parent = deque([start]), {start: None}
    else:
        frontier, parent, g = [(weight * h(p, start), next(cnt), start)], {start: None}, {start: 0}
    expanded = 0
    while frontier:
        s = frontier.popleft() if h is None else heapq.heappop(frontier)[2]
        expanded += 1
        if p.goal <= s:
            plan = []
            while parent[s] is not None:
                s, a = parent[s]; plan.append(a)
            return plan[::-1], expanded, time.perf_counter() - t0
        for a in p.actions:
            if a.applicable(s):
                s2 = a.apply(s)
                if h is None:
                    if s2 not in parent:
                        parent[s2] = (s, a); frontier.append(s2)
                elif s2 not in g or g[s] + a.cost < g[s2]:
                    g[s2] = g[s] + a.cost; parent[s2] = (s, a)
                    heapq.heappush(frontier, (g[s2] + weight * h(p, s2), next(cnt), s2))
    return None, expanded, time.perf_counter() - t0

# ---------- căutare înapoi (regresie) ----------
def regress(goal, a):
    """g' = (g − ADD(a)) ∪ PRE(a), doar dacă a este RELEVANTĂ (adaugă ceva din g) și CONSISTENTĂ (nu șterge nimic din g)."""
    if not (a.add & goal) or (a.dele & goal):
        return None
    return (goal - a.add) | a.pre

def bw_invalid(g):
    """Invarianți ai lumii blocurilor: elimină subscopuri imposibile (ex. handempty și holding(x))."""
    hold = [f for f in g if f.startswith("holding")]
    if len(hold) > 1 or (hold and "handempty" in g): return True
    below, above = {}, {}
    for f in g:
        if f.startswith("on("):
            x, y = f[3:-1].split(",")
            if x in below or y in above or f"clear({y})" in g or f"ontable({x})" in g: return True
            if f"holding({x})" in g or f"holding({y})" in g: return True
            below[x], above[y] = y, x
    for f in hold:
        x = f[8:-1]
        if f"clear({x})" in g or f"ontable({x})" in g: return True
    return False

def backward_search(p, invalid=lambda g: False, limit=50_000):
    t0 = time.perf_counter()
    frontier, parent, expanded = deque([p.goal]), {p.goal: None}, 0
    while frontier:
        g = frontier.popleft(); expanded += 1
        if expanded > limit:
            break                             # oprire de siguranță: spațiul subscopurilor explodează
        if g <= p.init:                       # subscopul curent e satisfăcut în starea inițială
            plan = []
            while parent[g] is not None:
                g, a = parent[g]; plan.append(a)
            return plan, expanded, time.perf_counter() - t0     # deja în ordinea execuției
        for a in p.actions:
            g2 = regress(g, a)
            if g2 is not None and g2 not in parent and not invalid(g2):
                parent[g2] = (g, a); frontier.append(g2)
    return None, expanded, time.perf_counter() - t0

def validate(p, plan):
    s = p.init
    for a in plan:
        assert a.applicable(s), f"{a} nu e aplicabilă"
        s = a.apply(s)
    return p.goal <= s

if __name__ == "__main__":
    # Anomalia lui Sussman: C peste A; B pe masă  ->  scop: A pe B pe C
    sussman = blocks_world(towers([["A", "C"], ["B"]]), {"on(A,B)", "on(B,C)"}, "ABC")
    six = blocks_world(towers([["A", "B", "C"], ["D", "E", "F"]]),
                       {"on(F,E)", "on(E,D)", "on(D,C)", "on(C,B)", "on(B,A)"}, "ABCDEF")
    for name, p in [("Sussman (3 blocuri)", sussman), ("6 blocuri", six)]:
        print(f"== {name}: {len(p.actions)} acțiuni instanțiate")
        runs = [("BFS înainte", lambda: forward_search(p)),
                ("A* h_goalcount", lambda: forward_search(p, h_goalcount)),
                ("A* h_max", lambda: forward_search(p, h_max)),
                ("A* h_add", lambda: forward_search(p, h_add)),
                ("BFS înapoi", lambda: backward_search(p)),
                ("BFS înapoi+inv", lambda: backward_search(p, bw_invalid))]
        for label, run in runs:
            plan, exp, t = run()
            ok = validate(p, plan) if plan else False
            print(f"  {label:15s} lungime={len(plan) if plan else '-':>3}  expandate={exp:6d}  timp={t*1000:8.1f} ms  valid={ok}")
        print("  plan:", forward_search(p, h_add)[0])
