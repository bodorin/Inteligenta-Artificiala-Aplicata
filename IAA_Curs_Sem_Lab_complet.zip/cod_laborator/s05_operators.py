"""Operatori genetici implementați de la zero: selecție, încrucișare, mutație (binar, real, permutări).
Rulare: python s05_operators.py   (rulează și testele de corectitudine)"""
import random, math

# ---------------- SELECȚIE (maximizare) ----------------
def tournament(pop, fits, k, rng):
    """Alege k indivizi la întâmplare și îl întoarce pe cel mai bun. Presiunea crește cu k."""
    best = max(rng.sample(range(len(pop)), k), key=lambda i: fits[i])
    return pop[best]

def rank_probs(n, s=1.5):
    """Selecție liniară pe ranguri (Baker): rangul 0 = cel mai slab. s ∈ [1, 2] = presiunea de selecție."""
    return [(2 - s) / n + 2 * i * (s - 1) / (n * (n - 1)) for i in range(n)]

def sus(pop, fits, n, rng):
    """Stochastic Universal Sampling: n „brațe” echidistante pe ruletă -> varianță minimă."""
    total = sum(fits); step = total / n; start = rng.uniform(0, step)
    chosen, acc, i = [], fits[0], 0
    for p in (start + j * step for j in range(n)):
        while acc < p:
            i += 1; acc += fits[i]
        chosen.append(pop[i])
    return chosen

# ---------------- ÎNCRUCIȘARE ----------------
def two_point(a, b, rng):
    i, j = sorted(rng.sample(range(1, len(a)), 2))
    return a[:i] + b[i:j] + a[j:], b[:i] + a[i:j] + b[j:]

def uniform(a, b, rng, p=0.5):
    m = [rng.random() < p for _ in a]
    return [x if t else y for x, y, t in zip(a, b, m)], [y if t else x for x, y, t in zip(a, b, m)]

def blx_alpha(a, b, rng, alpha=0.5, lo=-5.12, hi=5.12):
    """BLX-α (cromozomi reali): copilul e uniform în [min − αI, max + αI], I = |a_i − b_i|."""
    c = []
    for x, y in zip(a, b):
        mn, mx = min(x, y), max(x, y); I = mx - mn
        c.append(min(hi, max(lo, rng.uniform(mn - alpha * I, mx + alpha * I))))
    return c

def sbx(a, b, rng, eta=15):
    """Simulated Binary Crossover (Deb & Agrawal): imită pe reali încrucișarea cu un punct."""
    c1, c2 = [], []
    for x, y in zip(a, b):
        u = rng.random()
        beta = (2 * u) ** (1 / (eta + 1)) if u <= 0.5 else (1 / (2 * (1 - u))) ** (1 / (eta + 1))
        c1.append(0.5 * ((1 + beta) * x + (1 - beta) * y)); c2.append(0.5 * ((1 - beta) * x + (1 + beta) * y))
    return c1, c2

def pmx(a, b, rng, cut=None):
    """Partially Mapped Crossover (Goldberg & Lingle) pentru permutări."""
    n = len(a); i, j = cut or sorted(rng.sample(range(n + 1), 2))
    child = [None] * n
    child[i:j] = a[i:j]
    for k in range(i, j):
        v = b[k]
        if v in child[i:j]:
            continue
        pos = k
        while i <= pos < j:                     # urmăm maparea a[pos] -> poziția lui în b
            pos = b.index(a[pos])
        child[pos] = v
    return [b[k] if c is None else c for k, c in enumerate(child)]

def ox(a, b, rng, cut=None):
    """Order Crossover (Davis): păstrează segmentul din a, restul în ordinea relativă din b."""
    n = len(a); i, j = cut or sorted(rng.sample(range(n + 1), 2))
    seg = a[i:j]; rest = [x for x in b[j:] + b[:j] if x not in seg]
    child = [None] * n; child[i:j] = seg
    for k, pos in enumerate(list(range(j, n)) + list(range(0, i))):
        child[pos] = rest[k]
    return child

def cx(a, b):
    """Cycle Crossover (Oliver et al.): fiecare genă păstrează poziția din unul dintre părinți."""
    n, child, start, take_a = len(a), [None] * len(a), 0, True
    while None in child:
        start = child.index(None); pos = start
        while True:
            child[pos] = a[pos] if take_a else b[pos]
            pos = a.index(b[pos])
            if pos == start: break
        take_a = not take_a
    return child

# ---------------- MUTAȚIE ----------------
def bit_flip(x, pm, rng):            return [1 - g if rng.random() < pm else g for g in x]
def gaussian(x, sigma, pm, rng):     return [g + rng.gauss(0, sigma) if rng.random() < pm else g for g in x]
def swap(p, rng):
    p = p[:]; i, j = rng.sample(range(len(p)), 2); p[i], p[j] = p[j], p[i]; return p
def inversion(p, rng):
    p = p[:]; i, j = sorted(rng.sample(range(len(p) + 1), 2)); p[i:j] = reversed(p[i:j]); return p

# ---------------- CODIFICARE BINARĂ ----------------
def bits_needed(a, b, decimals):
    """Număr minim de biți ca intervalul [a, b] să fie reprezentat cu precizia 10^-decimals."""
    return math.ceil(math.log2((b - a) * 10 ** decimals + 1))
def gray(n):   return n ^ (n >> 1)
def ungray(g):
    n = 0
    while g: n ^= g; g >>= 1
    return n

if __name__ == "__main__":
    rng = random.Random(0)
    A, B = [1, 2, 3, 4, 5, 6, 7, 8, 9], [9, 3, 7, 8, 2, 6, 5, 1, 4]
    print("PMX(cut 3..7):", pmx(A, B, rng, (3, 7)))
    print("OX (cut 3..7):", ox(A, B, rng, (3, 7)))
    print("CX           :", cx(A, B))
    for _ in range(2000):                         # teste: copiii trebuie să fie permutări valide
        a = rng.sample(range(12), 12); b = rng.sample(range(12), 12)
        for c in (pmx(a, b, rng), ox(a, b, rng), cx(a, b), swap(a, rng), inversion(a, rng)):
            assert sorted(c) == list(range(12))
    print("teste permutări: OK")
    print("biți pentru [-1, 2] cu 6 zecimale:", bits_needed(-1, 2, 6))
    print("Gray:", [format(gray(i), "03b") for i in range(8)], "| invers OK:", all(ungray(gray(i)) == i for i in range(1000)))
    print("probabilități rang (n=5, s=2):", [round(p, 3) for p in rank_probs(5, 2.0)])
    k, n = 2, 5   # probabilitatea ca individul de rang r (1 = cel mai bun) să câștige un turnir de mărime k, cu întoarcere
    print("turnir k=2, n=5:", [round(((n - r + 1) ** k - (n - r) ** k) / n ** k, 3) for r in range(1, n + 1)])
