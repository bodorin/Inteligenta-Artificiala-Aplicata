"""Comparația cerută de fișa disciplinei: AG vs. PSO (Rastrigin) și AG vs. ACO (TSP),
la BUGET EGAL de evaluări, cu 10 rulări și test Mann–Whitney U.
Necesită fișierele din ședințele 5 și 7 în același director + pip install scipy."""
import time, statistics, random
from scipy.stats import mannwhitneyu
import s05_deap_rastrigin as GAR, s05_tsp_ga as GAT, s07_pso as PSO, s07_aco_tsp as ACO
from deap import algorithms, tools

def ga_rastrigin(seed, budget=20000, mu=100):
    """AG generațional (BLX-0.5, turnir 3) oprit exact la bugetul de evaluări."""
    random.seed(seed); tb = GAR.make_toolbox("blend")
    pop = tb.population(n=mu); evals = 0
    for ind in pop: ind.fitness.values = tb.evaluate(ind); evals += 1
    while evals < budget:
        off = algorithms.varAnd(tb.select(pop, mu), tb, cxpb=0.8, mutpb=0.2)
        for ind in off:
            if not ind.fitness.valid: ind.fitness.values = tb.evaluate(ind); evals += 1
        best = tools.selBest(pop, 1)[0]; pop = off; pop[0] = best        # elitism
    return min(ind.fitness.values[0] for ind in pop)

def compare(name, fa, fb, la, lb, runs=10):
    ta = time.perf_counter(); A = [fa(s) for s in range(runs)]; ta = (time.perf_counter() - ta) / runs
    tb = time.perf_counter(); B = [fb(s) for s in range(runs)]; tb = (time.perf_counter() - tb) / runs
    p = mannwhitneyu(A, B, alternative="two-sided").pvalue
    print(f"== {name}")
    for lab, X, t in ((la, A, ta), (lb, B, tb)):
        print(f"  {lab:28s} medie={statistics.mean(X):8.2f} mediană={statistics.median(X):8.2f} min={min(X):8.2f} timp/rulare={t:5.2f}s")
    print(f"  Mann–Whitney U: p = {p:.4f} -> " + ("diferență semnificativă (α = 0,05)" if p < 0.05 else "nicio diferență semnificativă"))

if __name__ == "__main__":
    compare("Rastrigin n=10, 20 000 de evaluări",
            ga_rastrigin, lambda s: PSO.pso(PSO.rastrigin, n=40, iters=500, w=0.9, w_end=0.4, c1=2, c2=2, seed=s)[0],
            "AG (BLX-0.5, turnir 3)", "PSO (w 0.9→0.4)")
    compare("TSP 30 de orașe, 6 000 de tururi evaluate",
            lambda s: GAT.run("ox", "inv", seed=s, mu=60, ngen=100)[0], lambda s: ACO.aco(mmas=True, seed=s)[0],
            "AG (OX + inversiune)", "ACO (MAX-MIN AS)")
